name = "Fred Flintstone"
location = "Bedrock Area"
relationship_status = "Married"
spouse = "Wilma Flintstone"
employer = "Slate Rock and Gravel"
job_title = "Bronto Crane Operator"
monthly_income = 3000.00

print("")
print("Name:         ", name)
print("Location:     ", location)
print("")
print("Relationship status:", relationship_status)
print("---- Spouse: ", spouse)
print("")
print("Employed By:", employer)
print("---- Occupation:   ", job_title)
print("---- Income:       ", monthly_income*12)