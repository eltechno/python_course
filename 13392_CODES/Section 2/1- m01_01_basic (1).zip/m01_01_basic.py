balance = 1000
name = "Chuck Black"
account_no = "01123581321"

print("name:", name, "    account:", account_no, "    balance:", balance)
print("name:", name, "    account:", account_no, "    balance:", "$" + str(balance))
print("name:", name, "    account:", account_no, "    balance:", "$" + str(float(balance)))

print("\n")
